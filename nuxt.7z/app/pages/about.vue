<template>
  <div>
    <h2>ℹ️ 关于我们</h2>
      这是“关于”页面的提示组件！
    <p>我们是一个使用 Nuxt 构建的现代化 Web 应用。</p>
    <p>路由路径： <code>/about</code></p>
  </div>
</template>

<style scoped>
h2 {
  color: #ff5722;
}
</style>