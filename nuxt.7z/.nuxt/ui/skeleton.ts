export default {
  "base": "animate-pulse rounded-md bg-elevated"
}